figure;
plot(error);
ylabel('time(u_sec)');
xlabel('sample_number');
title('error');