fileID=fopen('timestamps.txt','r');
A=fread(fileID,Inf,'int64');
fclose(fileID);