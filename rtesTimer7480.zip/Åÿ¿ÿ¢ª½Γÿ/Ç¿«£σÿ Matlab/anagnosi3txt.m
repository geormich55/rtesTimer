fileID=fopen('timestamps3.txt','r');
A=fread(fileID,Inf,'int64');
fclose(fileID);